﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PersonWebApp.Objects
{
    public class PersonRequestSettings
    {
        public string Index { get; set; }
        public string Type { get; set; }
        public string Id { get; set; }
        public string Method { get; set; }
    }
}
